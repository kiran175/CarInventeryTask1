package com.hcl.model;

public class CarDetails {
	private int id;
	private String make;
	private String model;
	private String year;
	private Double salesPrice;
	public CarDetails() {
		super();
	}
	
	public CarDetails(Integer id) {
		super();
		this.id = id;
	}

	public CarDetails(Integer carId,String make, String model, String year, Double salesPrice) {
		super();
		this.id = id;
		this.make = make;
		this.model = model;
		this.year = year;
		this.salesPrice = salesPrice;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public Double getSalesPrice() {
		return salesPrice;
	}
	public void setSalesPrice(Double salesPrice) {
		this.salesPrice = salesPrice;
	}
	@Override
	public String toString() {
		return "CarDetails [make=" + make + ", model=" + model + ", year=" + year + ", salesPrice=" + salesPrice + "]";
	}
	
	

}
