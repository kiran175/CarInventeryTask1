package com.hcl.main;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hcl.dao.CarInventryDao;
import com.hcl.model.CarDetails;

public class CarMain {

	public static void main(String[] args) {

		//@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		CarDetails carDetails = context.getBean("carDetails", CarDetails.class);
		CarInventryDao dao = context.getBean("edao", CarInventryDao.class);
		Scanner scanner=new Scanner(System.in);
		System.out.println("*****Welcome to Car Inventry System*****");
		
		System.out.println("Please enter the CMD:");
		String cmd1=scanner.next();

		switch(cmd1) {
		case "add":
			//System.out.println("enter the value car Id=" );	             
			//b.setId(sr.nextInt());
			
			System.out.println("enter the value car Make=" );	             
			carDetails.setMake(scanner.next());
			
			System.out.println("enter the value for Car Model=" );  
			carDetails.setModel(scanner.next());
			
			System.out.println("enter the value for Car Year=" );            
			carDetails.setYear(scanner.next());
			
			System.out.println("enter the value for Car Prise($)=" );            
			carDetails.setSalesPrice(scanner.nextDouble());
			
			dao.saveCardetails(carDetails);
			break;
		case "list":
			List li=dao.findAllCarDetails();
			System.out.println("Total No of cars "+li.size());
			li.forEach(lis->System.out.println(lis));
			break;

		case "quit":
			System.out.println("Thank you Visit again");
			System.out.println("Good Bye");
			break;
		default:
			System.out.println("Please enter correct cmd");
		}		
	}

}





