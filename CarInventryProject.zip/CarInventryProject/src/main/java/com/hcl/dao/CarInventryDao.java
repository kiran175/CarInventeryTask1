package com.hcl.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.model.CarDetails;

public class CarInventryDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	 public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void saveCardetails(CarDetails car) {
	        String query1 = "insert into Cardetails values"
	        		+ "("+car.getId()+",'"+car.getModel()+"','"+car.getMake()+"','"
	        		+car.getYear()+"','"+car.getSalesPrice()+ "')";
		
	        jdbcTemplate.update(query1);
	        System.out.println("CarDetails object Inserted in Data base.");
	    }
	
	public List findAllCarDetails() {
		return jdbcTemplate.queryForList("select * from carinventery.cardetails");
	}
	

}
